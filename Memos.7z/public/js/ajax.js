'use strict';

$(document).ready(function(){

	// ==================== Объявляем глобальные переменные ====================

	let chosenColor = "memo-white"; //Переменная, в который мы запишем название класса, которое соответствует выбранному цвету заметки, присваиваем значение по умолчанию
	let n=0; // Счетчик для создания уникальных имен (name) для полей (inputs) для сохранения list-items и link-items в заметке пользователя

	// ==================== Объявляем функции, которые будут нужны для работы с интерфейсом и данными ====================

	// Функция для активации тултипов для некоторых иконок
	function showTooltips(){
		$('.memo-link-add').tooltip();
		$('.memo-list-add').tooltip();
		$('.memo-link-show').tooltip();
		$('.memo-list-show').tooltip();
	}

	// Функция для активации поповера для выбора цвета заметки в модальном окне при создании / редактировании заметки
	function showPopoverForSelectingColor(){
		$('#modal-memo-colors-wrapper').hide();

		$('#change-modal-color').popover({
			content: $('#modal-memo-colors-wrapper'),
			placement: 'right',
			html: true
		});
	
		$('#change-modal-color').popover('show');
	
		$('#change-modal-color').popover('hide');
	
		$('#change-modal-color').on('hide.bs.popover', function () { // При закрытии поповера
			$('input[type=radio][name=ColorGroup]').prop('checked', false); // Очищаем радио с цветами
		});
	
		$('#modal-memo-colors-wrapper').show();
	
		// Скрыть поповер, если нажали не на него, а куда-то рядом
		$('body').on('click', function (e) {
			$('#change-modal-color').each(function () {
					if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
							$(this).popover('hide');
					}
			});
		});
	};

	// Функция для сохранения выбранного цвета заметки в ранее объявленную переменную chosenColor (перезаписываем значение по умолчанию)
	function saveChosenMemoColor(){
		$('input[type=radio][name=ColorGroup]').on('change', function(){ 
			chosenColor = $(".modal-memo-colors input[type='radio']:checked").val();
			$('#chosen-color').removeClass().addClass(chosenColor);
		});
	};

	// Функция для создания контейнеров для сохранения ссылок (link-items)
	function createMemoLinkItem(n){
		const memoLinkItem = 
	`
	<div class="memo-link-item">
		<div class="form-row align-items-center memo-link mt-1">
			<div class="col">
				<input type="url" class="form-control memo-link-href" placeholder="Скопіюйте лінк" name="memoLinkHref-${n}">
			</div>
			<div class="col">
				<input type="text" class="form-control memo-link-name" placeholder="Назвіть лінк" name="memoLinkName-${n}">
			</div>
			<div class="col-1">
				<i class="fas fa-trash memo-link-delete"></i>
			</div>
		</div>
	</div>
	`
	return memoLinkItem;
	}

	// Функция для создания контейнеров для сохранения списков (list-items)
	function createMemoListItem(n){
		const memoListItem = 
	`
	<div class="memo-list-item">
		<div class="form-row align-items-center memo-link mt-1">
			<div class="col">
				<input type="text" class="form-control memo-list-content" placeholder="Введіть текст" name="memoListItemContent-${n}">
			</div>
			<div class="col-1">
				<i class="fas fa-trash memo-list-delete"></i>
			</div>
		</div>
	</div>
	`
	return memoListItem;
	}

	// ===
	
	// ===

	// Функция для скрытия некоторых элементов интерфейса для ссылок и списков
	function hideMemoListsElements(){
		if ( $('.memo-links-wrapper').children().length == 0 && $('.memo-list-wrapper').children().length == 0) {
			$('.memo-link-add').hide();
			$('.link-heading').hide();
			$('.memo-list-add').hide();
			$('.list-heading').hide();
			};
	};

	// Функция-обработик первичного клика на значок добавления линков (показываем первый элемент для ссылок с инпутами)
	function showMemoLinkElements(){
		$('.memo-link-show').click(function(e){
			$('.memo-link-show').hide();
			$('.memo-list-show').hide();
			$('.list-heading').hide();
			$('.link-heading').show();
			$('.memo-link-add').show();
			$('.memo-links-wrapper').append(createMemoLinkItem(n));
			n++;
		});
	};

	// Функция-обработик первичного клика на значок добавления списка (показываем первый элемент для списка с инпутами)
	function showMemoListElements(){
		$('.memo-list-show').click(function(e){
			$('.memo-link-show').hide();
			$('.memo-list-show').hide();
			$('.link-heading').hide();
			$('.list-heading').show();
			$('.memo-list-add').show();
			$('.memo-list-wrapper').append(createMemoListItem(n));
			n++;
		});
	};

	// Функция-обработик последующих кликов на значок добавления линков (добавляем еще один link-item при каждом клике);
	function addNewLinkItem(){
		$(document).on('click', '.memo-link-add', function(e){
			$('.memo-links-wrapper').append(createMemoLinkItem(n));
			n++;
		});
	};
	
	// Функция-обработик последующих кликов на значок добавления списка (добавляем еще один list-item при каждом клике);
	function addNewListItem(){
		$(document).on('click', '.memo-list-add', function(e){
			$('.memo-list-wrapper').append(createMemoListItem(n));
			n++;
		});
	};

	// Функция для возврата линк-контейнера в исходное состояние
	function resetMemoLinksAndLists(){
		$('.link-heading').hide();
		$('.list-heading').hide();
		$('.memo-link-add').hide();
		$('.memo-list-add').hide();
		$('.memo-link-show').show();
		$('.memo-list-show').show();
		$('.memo-links-wrapper').empty();
		$('.memo-list-wrapper').empty();
		n = 0;
	}

	// Функция обработчик нажатия на иконку удаления ссылок (link-items)
	function deleteLinkItem(){

		$(document).on('click', '.memo-link-delete', function(e){

			e.preventDefault();
	
			// Удаляем выбранный link-item
			$(e.target).closest('.memo-link-item').remove(); 
	
			// Переименовали идентификаторы (в нашем случае все name у всех input), чтобы уникальность и порядковый номер не нарушились 
			let memoLinkHrefs = document.getElementsByClassName('memo-link-href');
	
			for(let i = 0; i < memoLinkHrefs.length; i++){
				memoLinkHrefs[i].setAttribute('name', `memoLinkHref-${i}`);
			};
	
			let memoLinkNames = document.getElementsByClassName('memo-link-name');
	
			for(let i = 0; i < memoLinkNames.length; i++){
				memoLinkNames[i].setAttribute('name', `memoLinkName-${i}`);
			};
	
			// Корректируем счетчик - порядковый номер названий инпутов для ссылок, чтобы при создании новых после удаления єтих уникальность и порядковый номер не нарушились
			n = memoLinkNames.length;
	
			// Если все блоки-контейнеры ссылок были удалены, то возращаем интерфейс в исходное состояние
			if(!$('.memo-link-item').length){
				resetMemoLinksAndLists();
			};
		
		});

	};

	// Функция обработчик нажатия на иконку удаления списка (list-items)
	function deleteListItem(){

		$(document).on('click', '.memo-list-delete', function(e){

			e.preventDefault();
	
			// Удаляем выбранный list-item
			$(e.target).closest('.memo-list-item').remove(); 
	
			// Переименовали идентификаторы (в нашем случае все name у всех input для списка), чтобы уникальность и порядковый номер не нарушились 
			let memoListItemContents = document.getElementsByClassName('memo-list-content');
	
			for(let i = 0; i < memoListItemContents.length; i++){
				memoListItemContents[i].setAttribute('name', `memoListItemContent-${i}`);
			};
	
			// Корректируем счетчик - порядковый номер названий инпутов для ссылок, чтобы при создании новых после удаления уникальность и порядковый номер не нарушились
			n = memoListItemContents.length;
	
			// Если все блоки-контейнеры ссылок были удалены, то возращаем интерфейс в исходное состояние
			if(!$('.memo-list-item').length){
				resetMemoLinksAndLists();
			};
		
		});;

	};

	// Агрегирующая функция для запуска все функций, которые отвечают за работу интерфейса модального окна создания / просмотра / редактирования заметки
	function allModalHandlers(){
		showTooltips();
		showPopoverForSelectingColor();
		saveChosenMemoColor();
		hideMemoListsElements();
		showMemoLinkElements();
		showMemoListElements();
		addNewLinkItem();
		addNewListItem();
		// resetMemoLinksAndLists();
		deleteLinkItem();
		deleteListItem();
	};

	// ==================== Создание новой заметки ====================

	// Отображаем пустое модальное окно для заполнения данных (на сервере рендерится pug-шаблон страницы, который мы выводим). 

	$(document).on('click', '#create-new-memo-modal', function(e){
		$.ajax({
			async: true,
			url: '/memos/show-create-memo-modal',
			contentType: 'application/json',
			method: 'GET',
			success: function (modal) {

				// Имплементим полученную разметку 
				$('#show-modal-body').empty();
				$('#show-modal-body').prepend(modal);
				
				// Запускаем функции, которые контролируют интерфейс модального окна создания заметки
				allModalHandlers();

				// Сразу после закрытия модалки
				$('#myModal').on('hidden.bs.modal', function (e) {
					console.log("memoLinkItem = " + createMemoLinkItem(n));
					console.log("memoListItem = " + createMemoListItem(n));
					console.log("n = " + n);
					$('#creating-new-memo').remove();
					// console.log("memoLinkItem = " + createMemoLinkItem(n));
					// console.log("memoListItem = " + createMemoListItem(n));
					// console.log("n = " + n);
				})

			}
		});
	});
	

	// Функция-обработчик для создания новой заметки при submit
	function createMemo(e) {

		e.preventDefault();

		let form = document.getElementById("form");
		// let saveBtn = document.getElementById("save-memo");
		// let memoHeader = document.getElementById("memoTitle");
		// let memoDescription = document.getElementById("memoDescription");
		// let memoDate = document.getElementById("memoDate");

		// let title = memoHeader.value;
		// let description = memoDescription.value;
		// let date = memoDate.value;
		// let memoLinks = [];
		// let memoList = [];

		let title = $('#memoTitle').val();
		let description = $('#memoDescription').val();
		let date = $('#memoDate').val();
		let memoLinks = [];
		let memoList = [];

		// Собираем линки (ссылки)
		let memoLinkItems = document.getElementsByClassName('memo-link-item');

		for(let i=0; i<memoLinkItems.length;i++){
			if(!$(`input[name="memoLinkHref-${i}"]`).val()) continue;
			let memoLink = {link: $(`input[name="memoLinkHref-${i}"]`).val(), linkText: $(`input[name="memoLinkName-${i}"]`).val() || $(`input[name="memoLinkHref-${i}"]`).val()};
			memoLinks.push(memoLink);
		}
		
		// Собираем список
		// let memoListItemContents = document.getElementsByClassName('memo-list-item');

		// for(let i=0; i<memoListItemContents.length;i++){
		// 	if(!$(`input[name="memoListItemContent-${i}"]`).val()) continue;
		// 	let memoListItem = $(`input[name="memoListItemContent-${i}"]`).val();
		// 	memoList.push(memoListItem);
		// }

		let memoListItemContents = document.getElementsByClassName('memo-list-item');

		for(let i=0; i<memoListItemContents.length;i++){
			if(!$(`input[name="memoListItemContent-${i}"]`).val()) continue;
			let memoListItem = {listItem: $(`input[name="memoListItemContent-${i}"]`).val(), listItemStatus: "todo", listItemId: ""};
			memoList.push(memoListItem);
		}

		// console.log(title);
		// console.log(description);
		// console.log(date);
		// console.log(checkedRad);
		//console.log(memoLinks);
		//console.log(memoLinks);
		// console.log(memoList);

		// Если форма форма проходит валидацию HTML5, то выполняем сабмит, иначе выводятся стандартные HTML5 подсказки
		if ($("#form")[0].checkValidity()){

			$.ajax({
				async: true,
				url: '/memos/create-memo',
				contentType: 'application/json',
				method: 'POST',
				data: JSON.stringify({
					title: title,
					description: description,
					date: date,
					color: chosenColor || 'memo-white',
					links: memoLinks,
					list: memoList
				}),
				success: function (memo) {

					// console.log(memo);

					$('#myModal').modal('hide'); // Закрываем модальное окно
					$('.memos').prepend('<div id="tmpdiv"></div>'); // Создаем элемент 
					$('#tmpdiv').replaceWith(memo); // Заменяем элемент тем, что получили с сервера
					$('input[type=radio][name=ColorGroup]').prop('checked', false); // Очищаем радио с цветом
					$('#chosen-color').removeClass(); // Удаляем класс-маркировку с выбранным цветом
					chosenColor = 'memo-white'; // Возвращаем цвет по умолчанию
					form.reset(); // Очищаем форму
					$('.memo-links-wrapper').empty(); // Очищаем в модалке блок со ссылками
					resetMemoLinksAndLists(); // Приводим блоки со ссілками и листами в исходное состояние
					n = 0; // Обнуляем счетчик для создания уникальных идентификаторов ссылок
				}
			});
	} else {
		$("#form")[0].reportValidity();
	}
	};

	$(document).on("click", "#save-memo", {}, createMemo);

	// Удаление заметки

	function deleteTheMemo(e){

		let memoId = $(e.target).closest('.memo').attr('id');

		$.ajax({
			async: true,
			url: '/memos/delete-memo/'+memoId,
			contentType: 'application/json',
			method: 'DELETE',
			data: JSON.stringify({
				memoId: memoId,
			}),
			success: function (memoid) {

				$('#'+memoid).remove();

			},
			error: function(err) {
        console.log(err);
      }
		});
		
	}

	$(document).on("click", '.memo-delete', {}, deleteTheMemo);

	// ==========================================Редактирование заметки==========================================

	// Сначала показываем заметку в модалке в режиме редактирования

	// function showMemoInModalEventHandler(e) {

	// 	let memoId = $(e.target).closest('.memo').attr('id');

	// 	$.ajax({
	// 		async: true,
	// 		url: '/memos/show-memo-for-update/'+memoId,
	// 		contentType: 'application/json',
	// 		get: 'PUT',
	// 		data: JSON.stringify({
	// 			memoId: memoId,
	// 		}),
	// 		success: function (memo) {

	// 			// $('#show-update-modal-body').empty(); // Сначала очищаем модалку редактирования на случай, если там что-то есть
	// 			// $('#show-update-modal-body').prepend(memo); // Далее полученный с сервера контент и вставляем в модалку

	// 			// memoUpdateModalPopover();
	// 			// showTooltips();
	// 			// showCurrentColorBeforeUpdate();
	// 			// changeColorForUpdate();
	// 			// hideMemoListsElements();
	// 			// showMemoLinkElements();
	// 			// showMemoListElements();

	// 			$('#show-modal-body').empty(); // Сначала очищаем модалку редактирования на случай, если там что-то есть
	// 			$('#show-modal-body').prepend(memo); // Далее полученный с сервера контент и вставляем в модалку

	// 			$('#myModal').on('hidden.bs.modal', function (e) {
	// 				$('#updating-old-memo').remove();
	// 			})

	// 			// memoUpdateModalPopover();
	// 			// showTooltips();
	// 			// showCurrentColorBeforeUpdate();
	// 			// changeColorForUpdate();
	// 			// hideMemoListsElements();
	// 			// showMemoLinkElements();
	// 			// showMemoListElements();
				
	// 			console.log(memo);

	// 		},
	// 		error: function(err) {
  //       console.log(err);
  //     }
	// 	});

	// }

	// $(document).on('click', '.memo-update', showMemoInModalEventHandler);



	// function updateMemo(e) {

	// 	e.preventDefault();

	// 	let memoId = $('.unique-memo').attr('id')//$(e.target).closest('.unique-memo').attr('id');
	// 	let newMemoTitle = $('#memoUpdateTitle').val()
	// 	let newMemoDescription = $('#memoUpdateDescription').val();
	// 	let newMemoDate = $('#memoUpdateDate').val();
	// 	let newMemoLinks = [];
	// 	let newMemoList = [];

	// 	let memoLinkItems = document.getElementsByClassName('memo-link-item');

	// 	for(let i=0; i<memoLinkItems.length;i++){
	// 		if(!$(`input[name="memoLinkHref-${i}"]`).val()) continue;
	// 		let memoLink = {link: $(`input[name="memoLinkHref-${i}"]`).val(), linkText: $(`input[name="memoLinkName-${i}"]`).val() || $(`input[name="memoLinkHref-${i}"]`).val()};
	// 		newMemoLinks.push(memoLink);
	// 	}

	// 	let memoListItemContents = document.getElementsByClassName('memo-list-item');

	// 	for(let i=0; i<memoListItemContents.length;i++){
	// 		if(!$(`input[name="memoListItemContent-${i}"]`).val()) continue;
	// 		let memoListItem = {listItem: $(`input[name="memoListItemContent-${i}"]`).val(), listItemStatus: "todo", listItemId: ""};
	// 		newMemoList.push(memoListItem);
	// 	}

	// 	console.log(newMemoLinks);
	// 	console.log(newMemoList);

	// 	if ($("#update-memo-form")[0].checkValidity()){

	// 		$.ajax({
	// 			async: true,
	// 			url: '/memos/update-memo/'+memoId,
	// 			contentType: 'application/json',
	// 			method: 'PUT',
	// 			data: JSON.stringify({
	// 				memoId: memoId,
	// 				newMemoTitle: newMemoTitle,
	// 				newMemoDescription: newMemoDescription,
	// 				newMemoLinks: newMemoLinks,
	// 				newMemoList: newMemoList,
	// 				newMemoColor: updateColor,
	// 				newMemoDate: newMemoDate
	// 			}),
	// 			success: function (info) {
	
	// 				console.log(info);
	
	// 			},
	// 			error: function(err) {
	// 				console.log(err);
	// 			}
	// 		});

	// 	} else {
	// 		$("#update-memo-form")[0].reportValidity();
	// 	}

	// };

	// $(document).on('click', '#update-memo', updateMemo);

});



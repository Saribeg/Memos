function createMemo(e) {

	e.preventDefault();

	let form = document.getElementById("form");
	let saveBtn = document.getElementById("save-memo");
	let memoHeader = document.getElementById("memoTitle");
	let memoDescription = document.getElementById("memoDescription");
	let memoDate = document.getElementById("memoDate");

	let title = memoHeader.value;
	let description = memoDescription.value;
	let date = memoDate.value;
	let memoLinks = [];
	let memoList = [];

	// Собираем линки (ссылки)
	let memoLinkItems = document.getElementsByClassName('memo-link-item');

	for(let i=0; i<memoLinkItems.length;i++){
		if(!$(`input[name="memoLinkHref-${i}"]`).val()) continue;
		let memoLink = {link: $(`input[name="memoLinkHref-${i}"]`).val(), linkText: $(`input[name="memoLinkName-${i}"]`).val() || $(`input[name="memoLinkHref-${i}"]`).val()};
		memoLinks.push(memoLink);
	}
	
	// Собираем список
	// let memoListItemContents = document.getElementsByClassName('memo-list-item');

	// for(let i=0; i<memoListItemContents.length;i++){
	// 	if(!$(`input[name="memoListItemContent-${i}"]`).val()) continue;
	// 	let memoListItem = $(`input[name="memoListItemContent-${i}"]`).val();
	// 	memoList.push(memoListItem);
	// }

	let memoListItemContents = document.getElementsByClassName('memo-list-item');

	for(let i=0; i<memoListItemContents.length;i++){
		if(!$(`input[name="memoListItemContent-${i}"]`).val()) continue;
		let memoListItem = {listItem: $(`input[name="memoListItemContent-${i}"]`).val(), listItemStatus: "todo", listItemId: ""};
		memoList.push(memoListItem);
	}

	// console.log(title);
	// console.log(description);
	// console.log(date);
	// console.log(checkedRad);
	//console.log(memoLinks);
	//console.log(memoLinks);
	// console.log(memoList);

	// Если форма форма проходит валидацию HTML5, то выполняем сабмит, иначе выводятся стандартные HTML5 подсказки
	if ($("#form")[0].checkValidity()){

		$.ajax({
			async: true,
			url: '/memos/create-memo',
			contentType: 'application/json',
			method: 'POST',
			data: JSON.stringify({
				title: title,
				description: description,
				date: date,
				color: chosenColor || 'memo-white',
				links: memoLinks,
				list: memoList
			}),
			success: function (memo) {

				// console.log(memo);

				$('#myModal').modal('hide'); // Закрываем модальное окно
				$('.memos').prepend('<div id="tmpdiv"></div>'); // Создаем элемент 
				$('#tmpdiv').replaceWith(memo); // Заменяем элемент тем, что получили с сервера
				$('input[type=radio][name=ColorGroup]').prop('checked', false); // Очищаем радио с цветом
				$('#chosen-color').removeClass(); // Удаляем класс-маркировку с выбранным цветом
				chosenColor = 'memo-white'; // Возвращаем цвет по умолчанию
				form.reset(); // Очищаем форму
				$('.memo-links-wrapper').empty(); // Очищаем в модалке блок со ссылками
				resetMemoLinksAndLists(); // Приводим блоки со ссілками и листами в исходное состояние
				n = 0; // Обнуляем счетчик для создания уникальных идентификаторов ссылок
			}
		});
} else {
	$("#form")[0].reportValidity();
}
};
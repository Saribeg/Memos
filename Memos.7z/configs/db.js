module.exports = {
	url: 'mongodb://Memos:m2018itDansvp2!@ds125684.mlab.com:25684/memos',
	dbName: 'memos'
}